var mapping = {
  'controller': 'real-controller.js',
  'utils/dialogs': 'real-dialogs.js'
};
